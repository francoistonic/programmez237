#!/usr/bin/env bash
# Install Contour
kubectl apply -f https://j.hept.io/contour-deployment-rbac

