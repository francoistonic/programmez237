module.exports = {
    "globDirectory": "aspnetcore-prerendering/obj/Release/netcoreapp3.0/PubTmp/Out/blazor-workbox-pwa/dist",
    "globPatterns": [
        '**/*.{html,json,js,css,png,ico,woff,,ttf,otf,json,wasm,dll}'
    ],
    "swDest": "aspnetcore-prerendering/obj/Release/netcoreapp3.0/PubTmp/Out/blazor-workbox-pwa/dist/sw.js"
};