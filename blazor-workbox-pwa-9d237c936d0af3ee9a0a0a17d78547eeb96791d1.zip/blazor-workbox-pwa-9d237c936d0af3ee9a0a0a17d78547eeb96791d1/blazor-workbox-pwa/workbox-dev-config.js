module.exports = {
    "globDirectory": "bin/Debug/netstandard2.0/dist",
    "globPatterns": [
        '**/*.{html,json,js,css,png,ico,json,wasm,dll}'
    ],
    "swDest": "wwwroot/sw.js"
};